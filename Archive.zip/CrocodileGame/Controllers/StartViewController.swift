//
//  StartViewController.swift
//  CrocodileGame
//
//  Created by Sergey on 16.04.2023.
//

import UIKit

class StartViewController: UIViewController {

    var backgroundImage: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = UIImage(named: "background")
        return imageView
    }()
    var crocodileImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = UIImage(named: "pngwing 1")
        return imageView
    }()
    var grassImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = UIImage(named: "grass 1")
        return imageView
    }()
    var grassImageViewTwo: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = UIImage(named: "grass 2")
        return imageView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
       setUpView()
        setUpConstrain()
       // view.backgroundColor = .red

    }
    
    func setUpView(){
        view.addSubview(backgroundImage)
        view.addSubview(crocodileImageView)
        view.addSubview(grassImageView)
        view.addSubview(grassImageViewTwo)
    }
    func setUpConstrain(){
        NSLayoutConstraint.activate([
            backgroundImage.topAnchor.constraint(equalTo: view.topAnchor),
            backgroundImage.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            backgroundImage.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            backgroundImage.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        
        
        NSLayoutConstraint.activate([
            crocodileImageView.topAnchor.constraint(equalTo: view.topAnchor, constant: 103),
            crocodileImageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 53),
            crocodileImageView.trailingAnchor.constraint(equalTo: view.trailingAnchor,constant: -53),
//            crocodileImageView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        NSLayoutConstraint.activate([
//            grassImageView.topAnchor.constraint(equalTo: view.topAnchor, constant: 103),
            grassImageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 53),
//            grassImageView.trailingAnchor.constraint(equalTo: view.trailingAnchor,constant: -53),
            grassImageView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            grassImageView.widthAnchor.constraint(equalToConstant: 70),
            grassImageView.heightAnchor.constraint(equalToConstant: 95)
            
        ])
        NSLayoutConstraint.activate([
//            grassImageViewTwo.topAnchor.constraint(equalTo: view.topAnchor, constant: 103),
//            grassImageViewTwo.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 53),
            grassImageViewTwo.trailingAnchor.constraint(equalTo: view.trailingAnchor,constant: -53),
            grassImageViewTwo.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            grassImageView.widthAnchor.constraint(equalToConstant: 70),
            grassImageView.heightAnchor.constraint(equalToConstant: 95)
        ])
    }
    
}

